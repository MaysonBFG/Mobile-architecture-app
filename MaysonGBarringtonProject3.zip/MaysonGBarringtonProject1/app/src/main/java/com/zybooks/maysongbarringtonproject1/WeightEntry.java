package com.zybooks.maysongbarringtonproject1;

public class WeightEntry {
    private String date;
    private int weight;
    private int goalWeight;

    public WeightEntry(String date, int weight, int goalWeight) {
        this.date = date;
        this.weight = weight;
        this.goalWeight = goalWeight;
    }

    // Getters
    public String getDate() { return date; }
    public int getWeight() { return weight; }
    public int getGoalWeight() { return goalWeight; }
}
