package com.zybooks.maysongbarringtonproject1;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import java.util.ArrayList;

public class WeightEntryAdapter extends BaseAdapter {
    private Context context;
    private ArrayList<WeightEntry> weightEntries;

    public WeightEntryAdapter(Context context, ArrayList<WeightEntry> weightEntries) {
        this.context = context;
        this.weightEntries = weightEntries;
    }

    @Override
    public int getCount() {
        return weightEntries.size();
    }

    @Override
    public Object getItem(int position) {
        return weightEntries.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        if (convertView == null) {
            convertView = LayoutInflater.from(context).inflate(android.R.layout.simple_list_item_2, parent, false);
        }

        WeightEntry entry = weightEntries.get(position);

        TextView dateView = convertView.findViewById(android.R.id.text1);
        TextView infoView = convertView.findViewById(android.R.id.text2);

        dateView.setText(entry.getDate());
        infoView.setText("Weight: " + entry.getWeight() + ", Goal: " + entry.getGoalWeight());

        return convertView;
    }
}

