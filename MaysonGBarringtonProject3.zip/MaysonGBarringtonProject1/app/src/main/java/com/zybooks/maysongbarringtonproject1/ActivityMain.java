package com.zybooks.maysongbarringtonproject1;

import android.app.DatePickerDialog;
import android.os.Bundle;
import android.text.InputType;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.GridView;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;
import java.util.Calendar;

public class ActivityMain extends AppCompatActivity {

    private EditText dateEditText, weightEditText, goalWeightEditText;
    private Button buttonAdd;
    private GridView gridView;
    private DataBaseHelper dbHelper;
    private ArrayList<WeightEntry> weightEntries;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main); //Link to activity_main.xml

        //initialize dbHelper
        dbHelper = new DataBaseHelper(this);

        //initialize UI elemets
        dateEditText = findViewById(R.id.editTextDate2);
        weightEditText = findViewById(R.id.editTextNumber2);
        goalWeightEditText = findViewById(R.id.editTextNumber3);
        buttonAdd = findViewById(R.id.buttonAdd);
        gridView = findViewById(R.id.gridView);

        //Load existing enteries from the database
        loadEntries();

        //Set up button click listener
        buttonAdd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String date = dateEditText.getText().toString();
                String weightString = weightEditText.getText().toString();
                String goalWeightString = goalWeightEditText.getText().toString();

                if (date.isEmpty() || weightString.isEmpty() || goalWeightString.isEmpty()) {
                    Toast.makeText(ActivityMain.this, "Please fill out all fields", Toast.LENGTH_SHORT).show();
                    return;
                }
                try {
                    int weight = Integer.parseInt(weightString);
                    int goalweight = Integer.parseInt(goalWeightString);

                    //add entry to database
                    if (dbHelper.addWeight(date, weight, goalweight)) {
                        Toast.makeText(ActivityMain.this, "Entry added!", Toast.LENGTH_SHORT).show();
                    } else {
                        Toast.makeText(ActivityMain.this, "Entry failed to add!", Toast.LENGTH_SHORT).show();
                    }
                } catch (NumberFormatException e) {
                    Toast.makeText(ActivityMain.this, "Please enter valid numbers for weight", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    private void loadEntries() {
        weightEntries = dbHelper.getAllWeightEntries(); //fetches entries from the DB
        WeightEntryAdapter adapter = new WeightEntryAdapter(this, weightEntries);
        gridView.setAdapter(adapter); //set adapter to gridview


        //set input type for weight and restrict to numbers only
        weightEditText.setInputType(InputType.TYPE_CLASS_NUMBER);
        goalWeightEditText.setInputType(InputType.TYPE_CLASS_NUMBER);

        //Set up DatePicker dialog for date selection
        buttonAdd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                showDatePicker();
            }
        });
    }

        private void showDatePicker() {
            final Calendar calendar = Calendar.getInstance();
            int year = calendar.get(Calendar.YEAR);
            int month = calendar.get(Calendar.MONTH);
            int day = calendar.get(Calendar.DAY_OF_MONTH);

            DatePickerDialog datepickerdialog = new DatePickerDialog(ActivityMain.this,(view, selectedYear, selectedMonth, selectedDay)-> {
                // format month to be 1-based
                selectedMonth++;
                String date = selectedDay + "/" + selectedMonth + "/" + selectedYear;
                dateEditText.setText(date); //set the selected date

            }, year, month, day);
            datepickerdialog.show();
        }
    private void validateInputs() {
        String weight = weightEditText.getText().toString();
        String goalWeight = goalWeightEditText.getText().toString();

        if (weight.length() > 3 || goalWeight.length() > 3){
            Toast.makeText(this, "Weight must be a maximum of 3 digits", Toast.LENGTH_SHORT).show();
            return;
        }
    }

    }



