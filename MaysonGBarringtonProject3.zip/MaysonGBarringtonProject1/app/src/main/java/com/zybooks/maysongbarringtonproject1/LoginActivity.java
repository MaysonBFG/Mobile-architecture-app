package com.zybooks.maysongbarringtonproject1;

import android.Manifest;
import android.content.pm.PackageManager;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.annotation.NonNull;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

public class LoginActivity extends AppCompatActivity {

    private static final int SMS_PERMISSION_CODE = 101;

    private EditText usernameEditText, passwordEditText;
    private Button loginButton, signupButton;
    private DataBaseHelper dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.login_screen); // Connect to the login screen layout

        // Initialize the database helper
        dbHelper = new DataBaseHelper(this);

        // Link XML elements to Java code
        usernameEditText = findViewById(R.id.editTextUsername);
        passwordEditText = findViewById(R.id.editTextPassword);
        loginButton = findViewById(R.id.logInButton);
        signupButton = findViewById(R.id.signUpButton);

        //Request SMS permission
        requestSmsPermissions();

        // Login button click listener
        loginButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String username = usernameEditText.getText().toString();
                String password = passwordEditText.getText().toString();

                if (username.isEmpty() || password.isEmpty()) {
                    Toast.makeText(LoginActivity.this, "Please fill out all fields", Toast.LENGTH_SHORT).show();
                } else {
                    // Call a function to log in the user
                    loginUser(username, password);
                }
            }
        });

        // Sign up button listener
        signupButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String username = usernameEditText.getText().toString();
                String password = passwordEditText.getText().toString();

                if (username.isEmpty() || password.isEmpty()) {
                    Toast.makeText(LoginActivity.this, "Please fill out all fields", Toast.LENGTH_SHORT).show();
                } else {
                    // Call the signup function
                    registerUser(username, password);
                }
            }
        });
    }

    private void requestSmsPermissions(){
        if (ContextCompat.checkSelfPermission(this,Manifest.permission.SEND_SMS)
        != PackageManager.PERMISSION_GRANTED){
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.SEND_SMS},SMS_PERMISSION_CODE);
        }

    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions,@NonNull int[] grantResults){
        super.onRequestPermissionsResult(requestCode,permissions,grantResults);
        if(requestCode == SMS_PERMISSION_CODE){
            if(grantResults.length >0 && grantResults[0] == PackageManager.PERMISSION_GRANTED){
                Toast.makeText(this,"SMS permission denied",Toast.LENGTH_SHORT).show();
                // the app continues to function with out the SMS feature
            }
        }
    }

    private void loginUser(String username, String password) {
        boolean userExists = dbHelper.checkUser(username, password);
        if (userExists) {
            Toast.makeText(LoginActivity.this, "Logged in successfully!", Toast.LENGTH_SHORT).show();

            // Redirect to the ActivityMain page after login
            Intent intent = new Intent(LoginActivity.this, ActivityMain.class);
            startActivity(intent);
        } else {
            Toast.makeText(LoginActivity.this, "Invalid username or password", Toast.LENGTH_SHORT).show();
        }
    }

    private void registerUser(String username, String password) {
        if (dbHelper.isUsernameTaken(username)) {
            Toast.makeText(LoginActivity.this, "Username is already taken", Toast.LENGTH_SHORT).show();
        } else {
            boolean insertSuccess = dbHelper.addUser(username, password);
            if (insertSuccess) {
                Toast.makeText(LoginActivity.this, "Registration successful!", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(LoginActivity.this, "Registration failed!", Toast.LENGTH_SHORT).show();
            }
        }
    }
}

